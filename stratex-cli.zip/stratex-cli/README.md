# STRATEX CLI

> Installe le framework d'orchestration multi-agents STRATEX dans ton projet Claude Code.

## Installation rapide

```bash
npx stratex@latest setup
```

C'est tout. La CLI te guide pour choisir les composants et installe tout automatiquement.

## Options

```bash
# Installation complète sans questions
npx stratex@latest setup --skip

# Installation dans un dossier personnalisé
npx stratex@latest setup --folder /mon/dossier/.claude
```

## Ce que ça installe

- **7 agents spécialisés** — analyst, architect, planner, researcher, reviewer, qa, action
- **7 commandes slash** — /route, /storify, /apex, /deep-research, /sprint-dashboard, /sync-sprint, /cleanup-context
- **5 hooks automatiques** — sécurité, coûts, notifications
- **4 règles contextuelles** — api, components, spec-system, bmad
- **Skills** — ralph-loop, ultrathink, apex (avec étapes progressives)

## Prérequis

- Node.js 18+ ou Bun
- Claude Code CLI (`npm install -g @anthropic-ai/claude-code`)
- Abonnement Claude Pro ou Max

## Documentation complète

👉 [github.com/oximore16-maker/stratex](https://github.com/oximore16-maker/stratex)

## Licence

MIT — Copyright (c) 2026 Oximore
