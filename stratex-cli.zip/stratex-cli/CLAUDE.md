# CLAUDE.md — STRATEX CLI

Ce fichier guide Claude Code quand il travaille sur le projet STRATEX CLI.

## Commandes de développement

- `bun run build` — Compile TypeScript vers dist/
- `bun run dev` — Lance la CLI en mode développement
- `bun run dev-test` — Teste l'installation dans un dossier temporaire
- `bun run release` — Publication automatique sur npm (version + build + tag + publish)

## Architecture

CLI TypeScript construite avec Bun et Commander.js.

### Structure

- `src/cli.ts` — Point d'entrée, définition des commandes
- `src/commands/setup.ts` — Logique d'installation principale
- `stratex-config/` — Fichiers de configuration copiés dans `~/.claude/`

### Processus d'installation

1. Sélection interactive des composants via `@clack/prompts`
2. Backup de la configuration existante
3. Copie des fichiers depuis `stratex-config/.claude/` vers `~/.claude/`
4. Rendu des hooks exécutables (`chmod +x`)
5. Mise à jour de `settings.json`

## Règle critique

Après chaque modification → tester avec `bun run dev-test`

## Avant d'éditer

Consulte la doc Claude Code pour les hooks et commandes :
https://docs.anthropic.com/claude-code
