#!/usr/bin/env node
import { Command } from "commander";
import { setupCommand } from "./commands/setup.js";

const program = new Command();

program
  .name("stratex")
  .description("Framework d'orchestration multi-agents pour Claude Code")
  .version("4.1.0");

program
  .command("setup")
  .description("Installe STRATEX dans ton projet Claude Code")
  .option("-f, --folder <path>", "Dossier d'installation personnalisé")
  .option("-s, --skip", "Installe tout sans questions")
  .action(async (options) => {
    await setupCommand({
      claudeFolder: options.folder,
      skipInteractive: options.skip,
    });
  });

program.parse();
