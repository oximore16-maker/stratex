import * as p from "@clack/prompts";
import chalk from "chalk";
import fs from "fs-extra";
import os from "os";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface SetupCommandParams {
  claudeFolder?: string;
  skipInteractive?: boolean;
}

interface SetupOptions {
  agents: boolean;
  commands: boolean;
  hooks: boolean;
  rules: boolean;
  skills: boolean;
  claudeMd: boolean;
}

export async function setupCommand(params: SetupCommandParams = {}) {
  const { claudeFolder: customFolder, skipInteractive } = params;

  console.log(
    chalk.bold.blue("\n🌉 STRATEX v4.1 — Setup\n")
  );
  console.log(
    chalk.gray("Framework d'orchestration multi-agents pour Claude Code\n")
  );

  // Dossier d'installation
  const claudeDir = customFolder
    ? path.resolve(customFolder)
    : path.join(os.homedir(), ".claude");

  console.log(chalk.gray(`📁 Installation dans : ${claudeDir}\n`));

  let options: SetupOptions;

  if (skipInteractive) {
    // Mode automatique — installe tout
    options = {
      agents: true,
      commands: true,
      hooks: true,
      rules: true,
      skills: true,
      claudeMd: true,
    };
    console.log(chalk.green("✓ Mode automatique — installation complète\n"));
  } else {
    // Mode interactif
    p.intro(chalk.bgBlue(" Sélectionne les composants à installer "));

    const selected = await p.multiselect({
      message: "Quels composants veux-tu installer ?",
      options: [
        {
          value: "agents",
          label: "Agents spécialisés (analyst, architect, planner, researcher, reviewer, qa, action)",
          hint: "recommandé",
        },
        {
          value: "commands",
          label: "Commandes slash (/route, /storify, /apex, /deep-research...)",
          hint: "recommandé",
        },
        {
          value: "hooks",
          label: "Hooks automatiques (sécurité, coûts, notifications)",
          hint: "recommandé",
        },
        {
          value: "rules",
          label: "Règles contextuelles (api, components, spec-system, bmad)",
          hint: "recommandé",
        },
        {
          value: "skills",
          label: "Skills auto-invoqués (ralph-loop, ultrathink, apex)",
          hint: "recommandé",
        },
        {
          value: "claudeMd",
          label: "CLAUDE.md — configuration principale",
          hint: "recommandé",
        },
      ],
      initialValues: ["agents", "commands", "hooks", "rules", "skills", "claudeMd"],
    });

    if (p.isCancel(selected)) {
      p.cancel("Installation annulée.");
      process.exit(0);
    }

    options = {
      agents: (selected as string[]).includes("agents"),
      commands: (selected as string[]).includes("commands"),
      hooks: (selected as string[]).includes("hooks"),
      rules: (selected as string[]).includes("rules"),
      skills: (selected as string[]).includes("skills"),
      claudeMd: (selected as string[]).includes("claudeMd"),
    };
  }

  // Source des fichiers STRATEX
  const sourceDir = path.join(__dirname, "../../stratex-config/.claude");

  // Créer le dossier destination
  await fs.ensureDir(claudeDir);

  const spinner = p.spinner();

  // Backup si config existante
  spinner.start("Vérification de la configuration existante");
  const backupDir = path.join(claudeDir, `backup-${Date.now()}`);
  if (await fs.pathExists(claudeDir)) {
    const existingFiles = await fs.readdir(claudeDir);
    if (existingFiles.length > 0) {
      await fs.copy(claudeDir, backupDir, {
        filter: (src) => !src.includes("backup-"),
      });
      spinner.stop(`Backup créé : ${chalk.gray(backupDir)}`);
    } else {
      spinner.stop("Aucune configuration existante");
    }
  }

  // Installation des composants
  if (options.agents) {
    spinner.start("Installation des agents");
    await fs.copy(
      path.join(sourceDir, "agents"),
      path.join(claudeDir, "agents"),
      { overwrite: true }
    );
    spinner.stop("✅ Agents installés (7 agents spécialisés)");
  }

  if (options.commands) {
    spinner.start("Installation des commandes");
    await fs.copy(
      path.join(sourceDir, "commands"),
      path.join(claudeDir, "commands"),
      { overwrite: true }
    );
    spinner.stop("✅ Commandes installées (/route, /storify, /apex, /deep-research...)");
  }

  if (options.hooks) {
    spinner.start("Installation des hooks");
    await fs.copy(
      path.join(sourceDir, "hooks"),
      path.join(claudeDir, "hooks"),
      { overwrite: true }
    );
    // Rendre les hooks exécutables
    const hooksDir = path.join(claudeDir, "hooks");
    const hookFiles = await fs.readdir(hooksDir);
    for (const file of hookFiles) {
      if (file.endsWith(".sh")) {
        await fs.chmod(path.join(hooksDir, file), 0o755);
      }
    }
    spinner.stop("✅ Hooks installés et configurés");
  }

  if (options.rules) {
    spinner.start("Installation des règles");
    await fs.copy(
      path.join(sourceDir, "rules"),
      path.join(claudeDir, "rules"),
      { overwrite: true }
    );
    spinner.stop("✅ Règles installées");
  }

  if (options.skills) {
    spinner.start("Installation des skills");
    await fs.copy(
      path.join(sourceDir, "skills"),
      path.join(claudeDir, "skills"),
      { overwrite: true }
    );
    spinner.stop("✅ Skills installés (ralph-loop, ultrathink, apex)");
  }

  if (options.claudeMd) {
    spinner.start("Installation de CLAUDE.md");
    const claudeMdDest = path.join(claudeDir, "CLAUDE.md");
    if (!await fs.pathExists(claudeMdDest)) {
      await fs.copy(
        path.join(sourceDir, "CLAUDE.md"),
        claudeMdDest
      );
      spinner.stop("✅ CLAUDE.md installé");
    } else {
      spinner.stop("⚠️  CLAUDE.md existant conservé — personnalise-le avec ta stack");
    }
  }

  // Installation settings.json
  spinner.start("Mise à jour de settings.json");
  const settingsSrc = path.join(sourceDir, "settings.json");
  const settingsDest = path.join(claudeDir, "settings.json");
  if (await fs.pathExists(settingsSrc)) {
    await fs.copy(settingsSrc, settingsDest, { overwrite: true });
    spinner.stop("✅ settings.json mis à jour");
  }

  // Résumé final
  p.outro(chalk.green("✨ STRATEX installé avec succès !"));

  console.log(chalk.bold("\n📖 Prochaines étapes :\n"));
  console.log(
    chalk.gray("  1. Ouvre ton projet dans Claude Code :\n") +
    chalk.white("     claude\n")
  );
  console.log(
    chalk.gray("  2. Personnalise CLAUDE.md avec ta stack :\n") +
    chalk.white(`     ${path.join(claudeDir, "CLAUDE.md")}\n`)
  );
  console.log(
    chalk.gray("  3. Lance ton premier workflow :\n") +
    chalk.white('     /route "ta première tâche"\n')
  );
  console.log(
    chalk.blue("📚 Documentation : https://github.com/oximore16-maker/stratex\n")
  );
}
