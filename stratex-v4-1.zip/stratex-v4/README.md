# STRATEX v3 🌉
### Le framework d'orchestration multi-agents pour Claude Code

> **Statut : Bêta expérimentale — framework conçu par raisonnement, pas encore testé en conditions réelles. Je cherche des devs pour tester et donner du feedback.**

<br>

![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)
![Status: Beta](https://img.shields.io/badge/Status-Beta-orange.svg)
![Claude Code](https://img.shields.io/badge/Claude-Code-purple.svg)

---

## Table des matières

1. [C'est quoi STRATEX ?](#cest-quoi-stratex-)
2. [Pourquoi ça existe ?](#pourquoi-ça-existe-)
3. [Ce que ça fait concrètement](#ce-que-ça-fait-concrètement)
4. [Installation](#installation)
5. [Workflow typique](#workflow-typique)
6. [Référence des agents](#référence-des-agents)
7. [Référence des commandes](#référence-des-commandes)
8. [Structure des fichiers](#structure-des-fichiers)
9. [Statut honnête](#statut-honnête)
10. [Ce que je cherche comme feedback](#ce-que-je-cherche-comme-feedback)
11. [Projets inspirants](#projets-inspirants)
12. [Licence](#licence)

---

## C'est quoi STRATEX ?

STRATEX est un framework de fichiers que tu glisses dans ton projet Claude Code. Il transforme Claude Code en un **système d'agents spécialisés** qui se coordonnent automatiquement.

Au lieu d'un seul Claude qui fait tout (et qui se perd dans 50 fichiers), tu as :

- Un **orchestrateur** qui reçoit ta demande, évalue sa complexité et délègue
- Des **agents spécialisés** qui exécutent chacun dans leur propre contexte isolé
- Des **commandes slash** qui structurent chaque étape du workflow
- Des **hooks automatiques** qui surveillent les coûts, la sécurité et l'état de session
- Des **skills** qui s'activent automatiquement quand la situation l'exige

**Le principe central :** chaque agent fait une seule chose, dans un contexte propre, et ne te retourne que ses conclusions. Ton contexte principal ne voit jamais le bruit intermédiaire.

---

## Pourquoi ça existe ?

J'ai combiné trois approches que j'admirais séparément et que je voulais faire fonctionner ensemble :

| Approche | Ce qu'elle apporte à STRATEX |
|---|---|
| [BMAD Method](https://github.com/bmadcode/bmad-agent) | Structuration du travail produit — briefs, user stories, sprints |
| [Apex Spec System](https://github.com/moshehbenavraham/apex-spec-system) | Implémentation guidée par la spec — Analyze, Plan, Execute, eXamine |
| [AIBlueprint](https://github.com/Melvynx/aiblueprint) | Patterns avancés pour Claude Code — hooks, skills, statusline |

La question que je me suis posée : *est-ce qu'on peut faire travailler ces trois approches ensemble, avec de vrais agents spécialisés qui se passent le contexte ?*

STRATEX v3 est ma tentative de réponse.

---

## Ce que ça fait concrètement

### 6 agents spécialisés

Chaque agent est invoqué via `@nom-agent` dans Claude Code. Il reçoit une tâche précise, travaille dans son propre contexte et te retourne uniquement ses conclusions.

| Agent | Modèle | Rôle |
|---|---|---|
| `@stratex-analyst` | Sonnet | Brief produit, analyse marché, clarification des besoins |
| `@stratex-architect` | Opus | Décisions d'architecture, ADR, choix techniques |
| `@stratex-planner` | Sonnet | User stories, sessions Apex, décomposition des tâches |
| `@stratex-researcher` | Sonnet | Deep research autonome sur 8 à 20 sources |
| `@stratex-reviewer` | Opus | Code review adversarial en 6 dimensions |
| `@stratex-qa` | Sonnet | Tests, validation, critères d'acceptance |

### 6 commandes slash

```bash
/route "ajouter authentification OAuth"    # Score 0-10 + sélection automatique du bon agent
/storify "page de profil utilisateur"      # Idée → spec.md + tasks.md structurés
/deep-research "quelle lib de queue ?"     # Research autonome multi-sources
/sprint-dashboard                           # Vue d'ensemble de l'état du sprint
/sync-sprint                                # Synchronisation BMAD ↔ Apex
/cleanup-context                            # Nettoyage du contexte en fin de session
```

### 5 hooks automatiques

Les hooks s'exécutent en arrière-plan sans que tu aies à y penser.

| Hook | Déclencheur | Ce qu'il fait |
|---|---|---|
| `log-spend.sh` | Après chaque outil | Enregistre le coût de la session |
| `security-check.sh` | Avant chaque commande bash | Bloque les opérations dangereuses |
| `notify.sh` | Fin de tâche longue | Notification système |
| `session-end.sh` | Fin de session | Résumé des coûts et actions |
| `post-commit.sh` | Après git commit | Log de l'activité |

### 2 skills auto-invoqués

- **ralph-loop** — s'active automatiquement quand les tests échouent en boucle sans progresser
- **ultrathink** — s'active pour les décisions complexes ou architecturales qui nécessitent un raisonnement profond

---

## Installation

### Prérequis

- Claude Code CLI installé (`npm install -g @anthropic-ai/claude-code`)
- Abonnement Claude Pro ou Max
- macOS ou Linux (les hooks bash ne fonctionnent pas sur Windows sans WSL)

### Étape 1 — Télécharger le ZIP

Sur cette page GitHub, clique sur **`stratex-communaute.zip`** → bouton **Download**.

### Étape 2 — Extraire le ZIP

```bash
unzip stratex-communaute.zip
```

Tu obtiens ce dossier :

```
stratex-communaute/
├── .claude/          ← Le cœur de STRATEX
├── LICENSE
└── README.md
```

### Étape 3 — Copier dans ton projet

```bash
cp -r stratex-communaute/.claude /chemin/vers/ton-projet/.claude
```

### Étape 4 — Rendre les hooks exécutables

```bash
cd /chemin/vers/ton-projet
chmod +x .claude/hooks/*.sh
```

### Étape 5 — Personnaliser CLAUDE.md

Ouvre `.claude/CLAUDE.md` et adapte les sections suivantes à ton projet :

```markdown
## WHAT
[Décris ton projet ici]

## WHY
[L'objectif métier de ton projet]

## HOW
[Ta stack technique — langage, frameworks, outils]
```

### Étape 6 — Lancer Claude Code

```bash
cd ton-projet
claude
```

Dans Claude Code, tape `/sprint-dashboard` pour vérifier que tout est en place.

---

## Workflow typique

```
Tu arrives avec une idée ou une tâche
              ↓
    /route "ta demande"
              ↓
    ┌─────────────────────────────────────────┐
    │  Score 1-3 (simple)                     │
    │  → Apex direct, pas d'agent             │
    ├─────────────────────────────────────────┤
    │  Score 4-6 (standard)                   │
    │  → @stratex-planner → implémentation    │
    ├─────────────────────────────────────────┤
    │  Score 7-10 (complexe)                  │
    │  → @stratex-analyst                     │
    │  → @stratex-architect                   │
    │  → @stratex-planner → implémentation    │
    └─────────────────────────────────────────┘
              ↓
    @stratex-qa        → Validation des critères d'acceptance
    @stratex-reviewer  → Code review adversarial
    /sync-sprint       → Mise à jour de l'état du sprint
    /cleanup-context   → Nettoyage du contexte en fin de session
```

### Exemple concret

```bash
# Tu veux ajouter une feature d'authentification
/route "ajouter authentification OAuth Google"

# → Score 7 → workflow complet recommandé
# → @stratex-architect invoqué automatiquement
# → Décisions d'architecture retournées
# → @stratex-planner invoqué
# → User stories + tasks.md créés
# → Tu implémentes
# → @stratex-reviewer pour la code review
# → @stratex-qa pour la validation
```

---

## Référence des agents

### @stratex-analyst

**Rôle :** Clarifier les besoins avant de coder. Évite de partir dans la mauvaise direction.

**Quand l'invoquer :**
- Tu as une idée vague qui nécessite d'être précisée
- Tu veux un brief produit structuré
- Tu as besoin d'une analyse marché rapide

**Ce qu'il retourne :** Un brief structuré avec contexte, objectifs, contraintes et critères de succès.

---

### @stratex-architect

**Rôle :** Décisions d'architecture et choix techniques. Documente ses décisions au format ADR.

**Quand l'invoquer :**
- Choix entre plusieurs approches techniques
- Conception d'une nouvelle fonctionnalité complexe
- Décisions qui auront un impact à long terme

**Ce qu'il retourne :** Un ADR documenté avec contexte, options considérées, décision retenue et conséquences.

---

### @stratex-planner

**Rôle :** Transformer un brief ou une spec en tâches concrètes et actionnables.

**Quand l'invoquer :**
- Après @stratex-architect pour décomposer le travail
- Pour créer des user stories BMAD
- Pour préparer une session Apex

**Ce qu'il retourne :** Un fichier `tasks.md` avec les tâches décomposées et un `spec.md` si nécessaire.

---

### @stratex-researcher

**Rôle :** Research autonome et approfondie sur une question technique ou stratégique.

**Quand l'invoquer :**
- Choisir entre plusieurs bibliothèques
- Comprendre les patterns recommandés pour un cas d'usage
- Analyser les alternatives à une approche

**Ce qu'il retourne :** Une synthèse de 8 à 20 sources avec recommandation argumentée.

---

### @stratex-reviewer

**Rôle :** Code review adversarial en 6 dimensions — il cherche activement les problèmes.

**Les 6 dimensions :** Correction, Performance, Sécurité, Maintenabilité, Tests, Architecture

**Quand l'invoquer :**
- Avant de merger du code important
- Après une session d'implémentation complexe
- Pour valider une décision technique

**Ce qu'il retourne :** Une liste de findings classés Critical / High / Medium / Low avec suggestions.

---

### @stratex-qa

**Rôle :** Validation que le code respecte les critères d'acceptance définis.

**Quand l'invoquer :**
- Après l'implémentation d'une feature
- Pour générer des cas de test
- Pour vérifier la couverture des critères d'acceptance

**Ce qu'il retourne :** Un rapport de validation avec les critères vérifiés et les gaps identifiés.

---

## Référence des commandes

### /route

**Usage :** `/route "description de ta demande"`

Évalue la complexité de ta demande sur une échelle de 0 à 10 et recommande le workflow adapté.

| Score | Complexité | Workflow recommandé |
|---|---|---|
| 1-3 | Simple | Apex direct |
| 4-6 | Standard | @stratex-planner → implémentation |
| 7-10 | Complexe | Analyse → Architecture → Planning → Implémentation |

---

### /storify

**Usage :** `/storify "description de la feature"`

Transforme une idée en spec et en tâches structurées. Crée automatiquement `spec.md` et `tasks.md`.

---

### /deep-research

**Usage :** `/deep-research "question technique"`

Lance une session de research autonome sur 8 à 20 sources avec synthèse et recommandation.

---

### /sprint-dashboard

**Usage :** `/sprint-dashboard`

Affiche l'état actuel du sprint — tâches en cours, terminées, bloquées, coût de session.

---

### /sync-sprint

**Usage :** `/sync-sprint`

Synchronise l'état BMAD (user stories) avec l'état Apex (implémentation). À utiliser en fin de session.

---

### /cleanup-context

**Usage :** `/cleanup-context`

Nettoie le contexte Claude Code en fin de session — compresse l'historique et archive les fichiers temporaires.

---

## Structure des fichiers

```
ton-projet/
└── .claude/
    ├── CLAUDE.md                       ← Configuration principale (à personnaliser)
    ├── settings.json                   ← Déclaration des hooks
    │
    ├── agents/                         ← 6 agents spécialisés
    │   ├── stratex-analyst.md
    │   ├── stratex-architect.md
    │   ├── stratex-planner.md
    │   ├── stratex-researcher.md
    │   ├── stratex-reviewer.md
    │   └── stratex-qa.md
    │
    ├── commands/                       ← 6 commandes slash
    │   ├── route.md
    │   ├── storify.md
    │   ├── deep-research.md
    │   ├── sprint-dashboard.md
    │   ├── sync-sprint.md
    │   └── cleanup-context.md
    │
    ├── hooks/                          ← 5 hooks automatiques
    │   ├── log-spend.sh
    │   ├── security-check.sh
    │   ├── notify.sh
    │   ├── session-end.sh
    │   └── post-commit.sh
    │
    ├── rules/                          ← Règles appliquées selon le contexte
    │   ├── api.md
    │   ├── components.md
    │   ├── spec-system.md
    │   └── bmad-docs.md
    │
    └── skills/                         ← 2 skills auto-invoqués
        ├── ralph-loop.md
        └── ultrathink.md
```

---

## Statut honnête

### ✅ Validé

- Structure de fichiers correcte pour Claude Code
- Prompts des agents cohérents et bien formatés
- Commandes slash logiques et correctement structurées
- `settings.json` des hooks valide
- Logique de routage de `/route` cohérente

### ⚠️ Pas encore testé en conditions réelles

- Les agents sur un vrai projet de A à Z
- Le workflow `/deep-research` (8-20 sources en autonomie)
- Les hooks bash selon les différentes stacks
- La coordination entre agents sur des tâches complexes
- Le coût réel en tokens sur des sessions longues

**Ce framework a été conçu par raisonnement**, en combinant des approches que j'admirais, sans avoir lancé Claude Code moi-même. C'est exactement pour ça que je le partage ici plutôt que de le présenter comme un produit fini.

---

## Ce que je cherche comme feedback

Si tu testes STRATEX, voici les questions qui m'intéressent le plus :

- Les agents s'invoquent-ils correctement avec la syntaxe `@stratex-nom` ?
- Le workflow `/route` → `/storify` → implémentation est-il fluide en pratique ?
- Quels agents sont les plus utiles ? Lesquels sont superflus ou mal calibrés ?
- Qu'est-ce qui plante en premier — hooks, agents, commandes ?
- Quel est le coût réel en tokens sur une session standard ?

Tous les retours sont les bienvenus — issues GitHub, ou directement en MP sur la communauté Renaud Dékode.

---

## Projets inspirants

STRATEX n'existerait pas sans ces projets :

- **[BMAD Method](https://github.com/bmadcode/bmad-agent)** — la méthode agile pour Claude Code
- **[Apex Spec System](https://github.com/moshehbenavraham/apex-spec-system)** — l'implémentation guidée par la spec
- **[AIBlueprint par Melvynx](https://github.com/Melvynx/aiblueprint)** — la référence pour les configs Claude Code avancées
- **[Claude Code Docs](https://docs.anthropic.com/claude-code)** — la documentation officielle

---

## Licence

MIT License — Copyright (c) 2026 Oximore

---

*Fait avec curiosité, partagé avec humilité. Tous les retours sont les bienvenus.*
