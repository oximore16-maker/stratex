# Changelog STRATEX

## v4.0.0 — Mars 2026

### Nouveautés majeures

**Infrastructure AIBlueprint adoptée**
- Agents réécrits en XML pur (suppression des `##` headings dans les bodies)
- Prompt caching : instructions stables en début de prompt, contexte variable en fin
- Tags XML requis : `<role>`, `<workflow>`, `<constraints>`, `<success_criteria>`

**Economy Mode (`/apex -e`)**
- Remplace tous les subagents par Glob/Grep/Read directs
- Économie ~70% des tokens
- Validations simplifiées (self-review au lieu d'adversarial review)
- Indicateur visuel `⚡ ECONOMY MODE` à chaque phase

**Workflow APEX intégré**
- Commande `/apex` avec flags complets (`-a`, `-s`, `-e`, `-b`, `-r`)
- 5 steps progressifs (step-00 à step-04)
- Scripts bash : `setup-templates.sh`, `update-progress.sh`
- Output sauvegardé dans `.claude/output/apex/{task-id}/` (si `-s`)
- Resume mode (`-r`) pour reprendre une tâche interrompue

**Nouvel agent `@stratex-action` (Haiku)**
- Tâches batch, renommages, formatage, boilerplate
- Modèle Haiku — rapide et économique
- Séparation claire : tâches simples vs raisonnement complexe

**TypeScript Validators**
- `validate-skill.ts` — Valide structure agents/commands/skills
- `package-skill.ts` — Pakage STRATEX en archive distribuable
- Validation frontmatter, tags XML requis, règles black box

### Améliorations

**Agents**
- `@stratex-analyst` : ajout `<success_criteria>`, suppression headings
- `@stratex-architect` : format ADR standardisé
- `@stratex-planner` : format tasks.md plus complet
- `@stratex-researcher` : XML pur + hint background execution
- `@stratex-reviewer` : classification Critical/High/Medium/Low
- `@stratex-qa` : tableau de critères d'acceptance

**CLAUDE.md**
- Statusline ajouté (model, sprint, stories, mode)
- Règles `<constraints>` explicites
- Tableau cost awareness Opus/Sonnet/Haiku
- Structure projet documentée

**settings.json**
- Matchers étendus : `npm test*`, `npx jest*`, `npx vitest*`, `npx tsc*`

---

## v3.0.0 — Janvier 2026

- Architecture multi-agents complète
- 6 subagents spécialisés
- Commandes `/deep-research`, `/sprint-dashboard`
- Skills ralph-loop et ultrathink
- Hooks Notification et Stop

## v2.0.0 — Décembre 2025

- Sécurité renforcée (security-check.sh)
- Rules par chemin
- Cost-aware routing (Sonnet/Haiku)

## v1.0.0 — Novembre 2025

- Bridge BMAD + Apex initial
- Commandes `/route`, `/storify`, `/sync-sprint`
- 2 hooks (PreToolUse, PostToolUse)
