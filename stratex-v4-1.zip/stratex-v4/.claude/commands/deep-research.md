---
description: Délègue une recherche approfondie à @stratex-researcher. Lance 8-20 recherches web séquentielles, croise les sources, et livre un rapport structuré avec recommandation claire. Idéal pour les décisions techniques importantes — choix de stack, architecture, librairies, analyse de marché.
argument-hint: "<sujet ou question à investiguer>"
---

<objective>
Déléguer la recherche reçue à @stratex-researcher et retourner un rapport structuré et actionnable.
</objective>

<workflow>
1. **Reformuler la question** — Clarifie et reformule la question pour maximiser la qualité de la recherche
2. **Estimer le scope** — Simple (8-10 recherches) ou Approfondi (15-20 recherches)
3. **Déléguer** — Lance @stratex-researcher avec les instructions complètes
4. **Présenter le rapport** — Affiche le rapport final avec mise en forme claire
</workflow>

<pre_delegation_check>
Avant de déléguer, évalue :
- La question est-elle suffisamment précise ? → Reformuler si vague
- Y a-t-il du contexte projet important à fournir ? → L'inclure dans le prompt
- S'agit-il d'une décision urgente ou exploratoire ? → Ajuster le scope
</pre_delegation_check>

<delegation_prompt_template>
```
Recherche approfondie sur : [question reformulée]

Contexte projet : [contexte extrait de CLAUDE.md / prd.md si disponible]

Focus particulier sur :
- [aspect 1 important pour le projet]
- [aspect 2]

Livrable attendu : Rapport avec recommandation claire et actionnable.
Scope : [8-10 | 15-20] recherches selon complexité.
```
</delegation_prompt_template>

<output_presentation>
Après réception du rapport de @stratex-researcher, présente-le avec :
1. **Résumé en 2 phrases** — La réponse essentielle
2. **Recommandation** — Mise en évidence claire
3. **Rapport complet** — Tel que livré par le researcher
4. **Prochaines étapes** — Quelle commande STRATEX utiliser ensuite
</output_presentation>

<constraints>
- ALWAYS reformuler la question avant de déléguer
- ALWAYS inclure le contexte projet dans le prompt de délégation
- NEVER synthétiser toi-même sans passer par @stratex-researcher
- Si question trop vaste → proposer de la décomposer en 2-3 recherches séparées
</constraints>
