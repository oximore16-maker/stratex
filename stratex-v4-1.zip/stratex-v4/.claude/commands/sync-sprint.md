---
name: sync-sprint
description: Bidirectional sync between BMAD sprint-status.yaml and Apex state.json. Surfaces lessons learned. v2 adds cost reporting.
---

# SYNC-SPRINT v2 — STRATEX Bidirectional Sync

## Objective
Maintain consistency between both systems after each session.
v2 adds a cost summary per session to inform future routing decisions.

## Process

### Step 1: Read all sources
- `.spec_system/state.json` (Apex source of truth)
- `docs/stories/sprint-status.yaml` (BMAD source of truth)
- `.claude/spend.log` (cost history) ← NEW v2

### Step 2: Calculate deltas
For each Apex session with status "completed":
1. Find source BMAD story (via link in spec.md)
2. Mark story as Done in sprint-status.yaml
3. Calculate % of epic completed

For each Apex session with status "in-progress":
1. Mark story as In Progress in sprint-status.yaml
2. Report completed tasks / total

### Step 3: Surface lessons learned
Read `.spec_system/CONSIDERATIONS.md`:
1. Identify entries added since last sync
2. Add to sprint-status.yaml as insights

### Step 4: Add cost summary (NEW v2)
Read `.claude/spend.log` and summarize per session:
```yaml
session_costs:
  - session: [session-id]
    estimated_budget_used: "[XX%]"
    recommendation: "[safe to repeat at L2 / split next time / L1 only]"
```

### Step 5: Update both files

**sprint-status.yaml:**
```yaml
sprint:
  name: [current sprint]
  updated_at: [timestamp]

epics:
  - id: E1
    stories:
      - id: S1.1
        status: [Done | In Progress | Todo | Blocked]
        session_apex: [session-id]
        completed_at: [date if Done]

progress:
  total_stories: N
  done: X
  in_progress: Y
  todo: Z
  percent_complete: XX%

lessons_learned:
  - session: [id]
    insight: "[lesson]"

session_costs:       ← NEW v2
  - [...]
```

### Step 6: Report

```
✅ STRATEX v2 SYNC-SPRINT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Stories updated: [N]
Lessons surfaced: [N]
Sprint progress: XX% ([X]/[N] stories)

Cost summary:
  Last session budget used: ~XX%
  Routing recommendation: [L1 / L2 / split]

Next recommended story: [title]
Command: /storify docs/stories/[epic]/[story].md
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```
