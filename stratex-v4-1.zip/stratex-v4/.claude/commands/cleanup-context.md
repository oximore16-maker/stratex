---
name: cleanup-context
description: Clears stale context and reloads only what's needed for the current session. Run at the START of every session.
---

# CLEANUP-CONTEXT — STRATEX v2

## Objective
Remove redundant or outdated information from working memory before starting a session.
This is the single most effective way to preserve context budget throughout a session.

## When to run
- **Mandatory:** at the START of every /implement session
- **Recommended:** when a session has been running for more than 2 hours
- **On demand:** when responses start feeling less accurate or coherent

## Process

### Step 1: Identify what to drop
The following are STALE after a session ends — drop them:
- Previous session's spec.md content
- Previous session's task list
- Error messages from previous iterations that are now resolved
- File contents that were read but won't be modified in this session
- Conversation turns older than 20 exchanges that contain implementation details

### Step 2: Identify what to keep
The following are ALWAYS relevant — keep them loaded:
- Current session's spec.md
- Current session's tasks.md (especially unchecked tasks)
- `.spec_system/CONVENTIONS.md`
- `.spec_system/CONSIDERATIONS.md`
- `docs/architecture.md` (relevant sections only)
- Active file being edited

### Step 3: Reload fresh
After clearing, explicitly reload:
1. Current spec: `.spec_system/specs/[current-session]/spec.md`
2. Current tasks: `.spec_system/specs/[current-session]/tasks.md`
3. Relevant rule file from `.claude/rules/` based on target file type
4. CONSIDERATIONS.md for known patterns

### Step 4: Report

```
🧹 CLEANUP-CONTEXT complete
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Stale context dropped: [describe what was cleared]
Fresh context loaded:
  - spec.md: [session-id]
  - tasks.md: [N remaining tasks]
  - Rules: [which rule file]
  - CONSIDERATIONS: [N entries]

Estimated context budget available: ~[XX]%
Ready to resume.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

## Budget guideline
After cleanup, context usage should be under 20% before starting implementation.
If it's still above 40% after cleanup → the session scope is too large, consider splitting.
