---
name: sprint-dashboard
description: Vue d'ensemble complète du sprint courant — progress, sessions, coûts, prochaine action recommandée. Usage: /sprint-dashboard
---

# SPRINT-DASHBOARD — STRATEX v3

## Objectif
Donner une vue d'ensemble instantanée de l'état du projet — où on en est, ce qui bloque, quoi faire ensuite.

## Processus

### Lire toutes les sources
1. `.spec_system/state.json` — sessions et statuts
2. `docs/stories/sprint-status.yaml` — stories et progress
3. `.spec_system/CONSIDERATIONS.md` — dernières leçons
4. `.claude/spend.log` — coûts session
5. `.spec_system/specs/` — sessions actives

### Format de sortie

```
╔══════════════════════════════════════════════════════╗
║           STRATEX SPRINT DASHBOARD                   ║
╠══════════════════════════════════════════════════════╣
║  Sprint : [nom]          Semaine [N]                 ║
╠══════════════════════════════════════════════════════╣
║  PROGRESS                                            ║
║  Stories : ██████░░░░ [X]/[N] ([XX]%)               ║
║  Sessions : █████░░░░░ [X]/[N] ([XX]%)              ║
╠══════════════════════════════════════════════════════╣
║  ÉPICS                                               ║
║  [Epic 1] : ██████████ 100% ✅                      ║
║  [Epic 2] : ████░░░░░░  40% 🔄                      ║
║  [Epic 3] : ░░░░░░░░░░   0% ⏳                      ║
╠══════════════════════════════════════════════════════╣
║  SESSION EN COURS                                    ║
║  [session-id] — [titre]                             ║
║  Tâches : [X]/[N] | Budget contexte : ~[XX]%        ║
╠══════════════════════════════════════════════════════╣
║  PROCHAINE ACTION RECOMMANDÉE                        ║
║  [commande exacte à exécuter]                        ║
╠══════════════════════════════════════════════════════╣
║  ALERTES                                             ║
║  [alertes si budget élevé, sessions bloquées, etc.]  ║
╠══════════════════════════════════════════════════════╣
║  DERNIÈRE LEÇON APPRISE                              ║
║  [dernière entrée CONSIDERATIONS.md]                 ║
╚══════════════════════════════════════════════════════╝
```

## Alertes automatiques
- 🔴 Si une session est bloquée depuis >24h → "Session [X] bloquée — intervention requise"
- 🟠 Si contexte >60% → "Budget élevé — termine la session courante avant d'en démarrer une nouvelle"
- 🟡 Si aucun sync depuis >3 sessions → "Sync BMAD en retard — lance /sync-sprint"
- 🟢 Si tout est vert → "Sprint en bonne forme — continue !"
