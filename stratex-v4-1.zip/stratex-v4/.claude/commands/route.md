---
description: Score la complexité de la tâche (0-10), détermine le niveau de traitement N1/N2/N3, identifie les agents recommandés, et suggère le mode d'exécution optimal.
argument-hint: "<description de la tâche>"
---

<objective>
Analyser la tâche reçue, scorer sa complexité, et recommander le workflow STRATEX optimal.
</objective>

<scoring_matrix>
**Facteurs de complexité (chacun ajoute 1-2 points) :**
- Touche plusieurs fichiers (>3) → +1
- Implique une décision architecturale → +2
- Nécessite de la recherche externe → +1
- Logique métier non triviale → +1
- Risque de régression sur l'existant → +1
- Intégrations tierces (API, DB, auth) → +1
- Performance critique → +1
- Première implémentation de ce type dans le projet → +1

**Échelle :**
- 0-3 : N1 — Tâche simple, exécution directe
- 4-6 : N2 — Feature standard, workflow APEX recommandé
- 7-10 : N3 — Complexité élevée, orchestration multi-agents
</scoring_matrix>

<dispatch_rules>
**N1 (0-3) — Exécution directe**
- Traitement : Agent principal seul ou `@stratex-action`
- Exemples : bug fix simple, refacto localisé, ajout de log
- Commande suggérée : `/apex -e <tâche>` (economy mode)

**N2 (4-6) — Workflow APEX**
- Traitement : `/apex -a <tâche>` ou `/apex -a -s <tâche>`
- Agents potentiels selon contexte : @stratex-analyst, @stratex-planner
- Exemples : nouvelle feature, endpoint API, composant UI complet

**N3 (7-10) — Orchestration multi-agents**
- Traitement : Séquence d'agents puis `/apex`
- Séquence recommandée selon type :
  - Feature produit : analyst → architect → planner → apex → reviewer → qa
  - Refacto majeur : architect → apex → reviewer
  - Recherche décision : researcher → architect → apex
  - Bug complexe : researcher → apex → qa
</dispatch_rules>

<output_format>
```
🎯 ROUTE: [titre court de la tâche]

Score de complexité : [N]/10
Niveau : N[1|2|3] — [Simple|Standard|Complexe]

Facteurs détectés :
- [facteur 1]
- [facteur 2]

Workflow recommandé :
[commande exacte à exécuter]

Agents impliqués :
1. @[agent] — [pourquoi]
2. @[agent] — [pourquoi]

Mode suggéré : [Standard | Economy -e si budget limité]

Estimation tokens : [Faible | Moyen | Élevé]
```
</output_format>

<examples>
**Input :** "Ajouter un console.log pour déboguer la fonction login"
**Output :**
Score : 1/10 — N1 Simple
Workflow : `/apex -e ajouter log debug fonction login`
Mode : Economy (tâche simple)

**Input :** "Implémenter l'authentification OAuth2 avec Google"
**Output :**
Score : 8/10 — N3 Complexe
Workflow : @stratex-researcher (patterns OAuth2) → @stratex-architect (design) → /apex -a -s (implémentation) → @stratex-reviewer (sécurité)
Mode : Standard

**Input :** "Créer un composant Button réutilisable"
**Output :**
Score : 3/10 — N1 Simple
Workflow : `/apex -e créer composant Button`
Mode : Economy
</examples>

<execution>
1. Lis la tâche reçue dans `$ARGUMENTS`
2. Évalue chaque facteur de la scoring matrix
3. Calcule le score total
4. Détermine le niveau N1/N2/N3
5. Construis la recommandation avec commandes exactes
6. Affiche le résultat au format défini
</execution>
