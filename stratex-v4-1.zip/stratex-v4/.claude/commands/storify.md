---
description: Transforme une idée ou feature en spec complète — génère spec.md (description technique) et tasks.md (stories Apex avec critères d'acceptance). Pont entre BMAD (vision produit) et Apex Spec System (implémentation).
argument-hint: "<idée ou feature à transformer>"
---

<objective>
Transformer l'idée reçue en documentation structurée prête à implémenter :
1. `docs/spec.md` — Spécification technique détaillée
2. `tasks/tasks.md` — Stories atomiques avec critères d'acceptance
</objective>

<workflow>
1. **Clarifier si nécessaire** — Si l'idée est vague, pose 2-3 questions via AskUserQuestion
2. **Lire le contexte existant** — Cherche docs/prd.md, docs/spec.md, CLAUDE.md pour comprendre le projet
3. **Générer spec.md** — Spécification complète au format ci-dessous
4. **Générer tasks.md** — Stories découpées, 15-30 min chacune
5. **Confirmer** — Affiche un résumé de ce qui a été créé
</workflow>

<spec_md_format>
```markdown
# Spec — [Nom de la feature]

**Version :** 1.0
**Date :** [date]
**Auteur :** STRATEX /storify

## Contexte
[Pourquoi cette feature existe — lien avec le produit global]

## Objectif
[Ce que cette feature accomplit — mesurable]

## Scope

### Inclus
- [fonctionnalité 1]
- [fonctionnalité 2]

### Exclu (v1)
- [ce qu'on ne fait pas maintenant]

## Spécification technique

### Architecture
[Diagramme ou description des composants impliqués]

### API / Interface
[Endpoints, props, signatures de fonctions si applicable]

### Données
[Schéma de données, modèles, migrations si applicable]

### Sécurité
[Considérations de sécurité spécifiques à cette feature]

## Critères d'acceptance globaux
- [ ] [critère 1]
- [ ] [critère 2]

## Définition of Done
- [ ] Code implémenté et fonctionnel
- [ ] Tests unitaires et intégration
- [ ] Code review @stratex-reviewer validé
- [ ] Documentation mise à jour
- [ ] Déployé en staging

## Dépendances
- [dépendance technique ou produit]
```
</spec_md_format>

<tasks_md_format>
```markdown
# Tasks — [Nom de la feature]

**Sprint suggéré :** Sprint [N]
**Estimation totale :** [X] minutes

## Stories

### Story [ID]-01 : [Titre]
**Priorité :** Must
**Estimation :** [15|30|45|60] min

En tant que [persona], je veux [action] afin de [bénéfice].

**Critères d'acceptance :**
- [ ] AC1 : [mesurable]
- [ ] AC2 : [mesurable]

**Notes techniques :** [indications si nécessaire]

---

[répéter pour chaque story]
```
</tasks_md_format>

<constraints>
- NEVER créer une story de plus de 60 min
- ALWAYS commencer par lire le contexte projet existant
- ALWAYS créer les deux fichiers (spec.md ET tasks.md)
- Découpage minimal : même une petite feature = minimum 2 stories
- Si feature complexe : signaler qu'il faudrait passer par @stratex-analyst d'abord
</constraints>

<success_criteria>
- spec.md créé dans docs/
- tasks.md créé dans tasks/
- Chaque story a au moins 2 critères d'acceptance
- Scope clairement défini (inclus ET exclu)
- Estimation totale cohérente avec les stories
</success_criteria>
