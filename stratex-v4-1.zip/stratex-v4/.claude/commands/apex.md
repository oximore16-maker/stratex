---
description: Workflow APEX complet (Analyze-Plan-Execute-Validate) pour l'implémentation structurée de features, corrections de bugs, ou refactorings. Utilise des agents parallèles en mode standard ou des outils directs en mode economy pour économiser les tokens.
argument-hint: "[-a] [-s] [-e] [-b] [-r <task-id>] <description de la tâche>"
---

<objective>
Exécuter un workflow APEX structuré en 4 phases pour implémenter la tâche reçue avec qualité et traçabilité.
</objective>

<quick_start>
```bash
# Usage de base
/apex implémenter authentification JWT

# Mode autonome + sauvegarde
/apex -a -s implémenter authentification JWT

# Mode economy (pas de subagents, ~70% tokens)
/apex -e implémenter authentification JWT

# Reprendre une tâche
/apex -r 01-auth-jwt
```
</quick_start>

<flags>
| Flag | Description |
|------|-------------|
| `-a` | Auto mode — skip confirmations, options recommandées automatiques |
| `-s` | Save mode — sauvegarde chaque étape dans `.claude/output/apex/` |
| `-e` | Economy mode — remplace tous les subagents par Glob/Grep/Read directs (~70% tokens) |
| `-b` | Branch mode — vérifie et crée une branche feature si on est sur main |
| `-r <id>` | Resume mode — reprend une tâche précédente |
</flags>

<workflow_phases>
```
Phase 0 : Init    → Parse flags, setup, create output structure
Phase 1 : Analyze → Explorer le codebase et comprendre le contexte
Phase 2 : Plan    → Stratégie d'implémentation fichier par fichier
Phase 3 : Execute → Implémentation avec todo-list
Phase 4 : Validate → Typecheck, tests, self-review
```
</workflow_phases>

<economy_mode_detail>
**Quand `-e` est actif :**

Au lieu de lancer des subagents d'exploration, utilise directement :
- `Glob` pour trouver les fichiers concernés
- `Grep` pour chercher des patterns
- `Read` pour examiner les fichiers clés (3-5 max)
- `WebSearch` seulement si absolument nécessaire (max 2)

Indicateur visuel : affiche `⚡ ECONOMY MODE` en début de chaque phase.
</economy_mode_detail>

<output_structure>
**Si `-s` est actif :**
```
.claude/output/apex/{task-id}/
├── 00-context.md   ← params, timestamp, critères d'acceptance
├── 01-analyze.md   ← findings de l'analyse
├── 02-plan.md      ← stratégie d'implémentation
├── 03-execute.md   ← log d'exécution
└── 04-validate.md  ← résultats de validation
```
</output_structure>

<execution>
**PREMIÈRE ACTION :** Charger `.claude/skills/apex/steps/step-00-init.md`

Ce fichier gère :
- Parsing de tous les flags
- Mode resume si `-r` fourni
- Création de la structure output si `-s`
- Initialisation des variables d'état

Puis enchaîner step-01 → step-02 → step-03 → step-04.
</execution>

<constraints>
- NEVER sauter une phase sans raison explicite
- ALWAYS utiliser ULTRA THINK avant les décisions d'implémentation importantes
- En economy mode : NEVER lancer de subagents (Task tool)
- Si tests échouent en phase 4 → activer ralph-loop skill automatiquement
- ALWAYS afficher un résumé de completion en fin de workflow
</constraints>
