---
name: ultrathink
description: Mode de réflexion profonde pour les décisions complexes, architecturales, ou quand une approche simple ne semble pas suffire. S'active automatiquement avant les décisions importantes dans le workflow APEX.
---

<objective>
Activer un mode de réflexion approfondie pour produire la meilleure solution possible, pas la première solution acceptable.
</objective>

<philosophy>
**Think Different.** La première solution qui vient à l'esprit est rarement la meilleure.
Prends le temps de comprendre le vrai problème avant de coder.

**Obsess Over Details.** Les bugs naissent dans les détails ignorés.
Quels edge cases ? Quelles dépendances cachées ? Quels effets de bord ?

**Plan Like Da Vinci.** Esquisse avant de construire.
Un plan bien pensé de 10 minutes évite 2 heures de refactoring.

**Craft Don't Code.** Tu construis quelque chose qui durera.
Code lisible, testable, maintenable — pas juste fonctionnel.

**Iterate Relentlessly.** La première implémentation est un brouillon.
Qu'est-ce qui peut être simplifié ? Qu'est-ce qui est encore fragile ?
</philosophy>

<activation_triggers>
Activer ultrathink automatiquement quand :
- Score de complexité STRATEX ≥ 7
- Décision architecturale (choix de pattern, refactoring majeur)
- La solution évidente semble trop simple ou trop complexe
- Un bug est difficile à reproduire ou à localiser
- Plusieurs approches semblent également valables
</activation_triggers>

<deep_thinking_process>
Quand ultrathink est actif :

1. **Reformuler le problème**
   → Quelle est la vraie question ? (pas la question de surface)

2. **Explorer les contraintes**
   → Performance, maintenabilité, sécurité, équipe, timeline

3. **Générer au moins 3 approches différentes**
   → Ne pas s'arrêter à la première solution

4. **Évaluer les trade-offs**
   → Court terme vs long terme, simplicité vs flexibilité

5. **Choisir et justifier**
   → Décision explicite avec raisons

6. **Anticiper les échecs**
   → Que se passe-t-il si cette approche échoue ?
   → Plan B ?
</deep_thinking_process>

<output_format>
```markdown
## UltraThink — [Problème]

### Reformulation
[Le vrai problème derrière la question posée]

### Contraintes identifiées
- [contrainte 1]
- [contrainte 2]

### Options explorées

**Option A :** [nom]
- Pour : [avantages]
- Contre : [inconvénients]

**Option B :** [nom]
- Pour : [avantages]
- Contre : [inconvénients]

**Option C :** [nom]
- Pour : [avantages]
- Contre : [inconvénients]

### Décision
**[Option choisie]** — [justification en 1-2 phrases]

### Risques anticipés
- [risque 1] → [mitigation]
```
</output_format>
