---
name: ralph-loop
description: Skill de récupération automatique quand les tests échouent — diagnostique, corrige, relance en boucle jusqu'à ce que tout passe. S'active automatiquement en phase de validation APEX si les tests échouent.
---

<objective>
Diagnostiquer et corriger les tests en échec de façon itérative jusqu'à ce que la suite complète passe.
</objective>

<workflow>
**Boucle de récupération :**

1. **Analyser les erreurs**
   - Lire le log complet des tests en échec
   - Identifier la cause racine (pas le symptôme)
   - Classifier : bug logique / mauvais test / dépendance manquante / config

2. **Corriger**
   - Appliquer le fix minimal qui résout la cause racine
   - Ne pas corriger le test pour qu'il passe artificiellement
   - Préférer corriger le code si le test est correct

3. **Relancer**
   ```bash
   npm test
   # OU
   npx jest --testPathPattern=[fichier concerné]
   ```

4. **Évaluer**
   - Si tous les tests passent → EXIT SUCCESS
   - Si même erreur → approche différente nécessaire
   - Si nouvelle erreur → la correction a introduit un autre bug
   - Maximum 5 itérations → escalader si toujours bloqué

5. **Escalader si nécessaire**
   - Si après 5 itérations les tests ne passent pas
   - Générer un rapport de diagnostic pour l'utilisateur
   - Demander de l'aide via AskUserQuestion (depuis le main chat uniquement)
</workflow>

<diagnostic_format>
```markdown
## Diagnostic Ralph Loop — Itération [N]

### Erreur détectée
```
[message d'erreur exact]
```

### Cause racine identifiée
[analyse de la vraie cause, pas du symptôme]

### Fix appliqué
[description du changement]

### Résultat
✅ Tests passent | ❌ Toujours en échec — itération [N+1]
```
</diagnostic_format>

<constraints>
- NEVER modifier un test pour qu'il passe artificiellement sans raison valide
- NEVER continuer après 5 itérations sans escalader
- ALWAYS identifier la cause racine avant de corriger
- Si les tests testent un comportement incorrect → noter et signaler, ne pas supprimer
</constraints>
