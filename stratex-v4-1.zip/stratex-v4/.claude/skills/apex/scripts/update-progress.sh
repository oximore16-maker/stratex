#!/bin/bash
# APEX Progress Update Script — STRATEX v4
# Met à jour la table de progression dans 00-context.md

set -e

TASK_ID="$1"
STEP_NUMBER="$2"
STEP_NAME="$3"
STATUS="$4"  # "in_progress" ou "complete"

if [[ -z "$TASK_ID" ]] || [[ -z "$STEP_NUMBER" ]] || [[ -z "$STEP_NAME" ]] || [[ -z "$STATUS" ]]; then
    echo "Usage: $0 <task_id> <step_number> <step_name> <status>"
    echo "Exemple: $0 01-add-auth 01 analyze complete"
    exit 1
fi

PROJECT_ROOT=$(git rev-parse --show-toplevel 2>/dev/null || pwd)
CONTEXT_FILE="${PROJECT_ROOT}/.claude/output/apex/${TASK_ID}/00-context.md"

if [[ ! -f "$CONTEXT_FILE" ]]; then
    echo "Error: Fichier de contexte introuvable : $CONTEXT_FILE"
    exit 1
fi

TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

if [[ "$STATUS" == "in_progress" ]]; then
    STATUS_SYMBOL="⏳ En cours"
elif [[ "$STATUS" == "complete" ]]; then
    STATUS_SYMBOL="✅ Terminé"
else
    echo "Error: Statut invalide. Utilise 'in_progress' ou 'complete'"
    exit 1
fi

TEMP_FILE=$(mktemp)

awk -v step="${STEP_NUMBER}-${STEP_NAME}" \
    -v status="$STATUS_SYMBOL" \
    -v timestamp="$TIMESTAMP" '
{
    if ($0 ~ "\\| " step " \\|") {
        printf "| %s | %s | %s |\n", step, status, timestamp
    } else {
        print $0
    }
}' "$CONTEXT_FILE" > "$TEMP_FILE"

mv "$TEMP_FILE" "$CONTEXT_FILE"

echo "✓ Progression mise à jour : ${STEP_NUMBER}-${STEP_NAME} → ${STATUS_SYMBOL}"
exit 0
