#!/bin/bash
# APEX Template Setup Script — STRATEX v4
# Crée la structure output et initialise les fichiers templates
#
# Usage: setup-templates.sh <feature_name> <task_description> <auto> <save> <economy> <branch> <branch_name>

set -e

FEATURE_NAME="$1"
TASK_DESCRIPTION="$2"
AUTO_MODE="${3:-false}"
SAVE_MODE="${4:-false}"
ECONOMY_MODE="${5:-false}"
BRANCH_MODE="${6:-false}"
BRANCH_NAME="${7:-}"

if [[ -z "$FEATURE_NAME" ]] || [[ -z "$TASK_DESCRIPTION" ]]; then
    echo "Error: FEATURE_NAME et TASK_DESCRIPTION sont requis"
    exit 1
fi

TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
PROJECT_ROOT=$(git rev-parse --show-toplevel 2>/dev/null || pwd)
APEX_OUTPUT_DIR="${PROJECT_ROOT}/.claude/output/apex"

mkdir -p "$APEX_OUTPUT_DIR"

# Trouver le prochain numéro disponible
NEXT_NUM=1
if [[ -d "$APEX_OUTPUT_DIR" ]]; then
    HIGHEST=$(ls -1 "$APEX_OUTPUT_DIR" 2>/dev/null | grep -oE '^[0-9]+' | sort -n | tail -1)
    if [[ -n "$HIGHEST" ]]; then
        NEXT_NUM=$((10#$HIGHEST + 1))
    fi
fi

TASK_NUM=$(printf "%02d" "$NEXT_NUM")
TASK_ID="${TASK_NUM}-${FEATURE_NAME}"
OUTPUT_DIR="${APEX_OUTPUT_DIR}/${TASK_ID}"

mkdir -p "$OUTPUT_DIR"

# Créer 00-context.md
cat > "${OUTPUT_DIR}/00-context.md" << EOF
# APEX Task: ${TASK_ID}

**Créé:** ${TIMESTAMP}
**Tâche:** ${TASK_DESCRIPTION}
**Branche:** ${BRANCH_NAME:-main}

## Configuration

| Flag | Valeur |
|------|--------|
| auto_mode | ${AUTO_MODE} |
| save_mode | ${SAVE_MODE} |
| economy_mode | ${ECONOMY_MODE} |
| branch_mode | ${BRANCH_MODE} |

## Critères d'acceptance
- [ ] AC1: À définir lors de l'analyse
- [ ] AC2: À définir lors de l'analyse

## Progression

| Étape | Statut | Timestamp |
|-------|--------|-----------|
| 01-analyze | ⏳ En attente | - |
| 02-plan | ⏳ En attente | - |
| 03-execute | ⏳ En attente | - |
| 04-validate | ⏳ En attente | - |
EOF

# Créer les fichiers d'étapes vides avec header
for step in "01-analyze" "02-plan" "03-execute" "04-validate"; do
    step_name="${step#*-}"
    cat > "${OUTPUT_DIR}/${step}.md" << EOF
# APEX ${step_name^} — ${TASK_ID}

**Tâche:** ${TASK_DESCRIPTION}
**Timestamp:** ${TIMESTAMP}

---

EOF
done

echo "TASK_ID=${TASK_ID}"
echo "OUTPUT_DIR=${OUTPUT_DIR}"
echo "✓ APEX templates initialisés : ${OUTPUT_DIR}"
exit 0
