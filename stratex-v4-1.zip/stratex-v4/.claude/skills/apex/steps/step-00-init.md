---
name: step-00-init
description: Initialise le workflow APEX — parse les flags, détecte le mode resume, crée la structure output
next_step: steps/step-01-analyze.md
---

# Step 0 : Initialisation

## RÈGLES OBLIGATOIRES

- 🛑 NEVER sauter le parsing des flags
- ✅ ALWAYS parser TOUS les flags avant toute autre action
- 📋 TU ES UN INITIALISEUR — pas un exécuteur
- 🚫 INTERDIT de charger step-01 avant que l'init soit complète
- ✅ Output COMPACT — un tableau, puis "→ Analyse en cours..."

---

## DEFAULTS

```yaml
auto_mode: false       # -a : skip confirmations
save_mode: false       # -s : sauvegarde outputs
economy_mode: false    # -e : pas de subagents, outils directs
branch_mode: false     # -b : vérifie/crée branche feature
resume_task: ""        # -r : reprend une tâche existante
```

---

## SÉQUENCE D'EXÉCUTION

### 1. Charger les defaults et parser les flags

```
Activer (minuscules) :
  -a / --auto     → auto_mode = true
  -s / --save     → save_mode = true
  -e / --economy  → economy_mode = true
  -b / --branch   → branch_mode = true
  -r <id>         → resume_task = <id>

Désactiver (majuscules) :
  -A → auto_mode = false
  -S → save_mode = false
  -E → economy_mode = false
  -B → branch_mode = false

Reste après suppression des flags = {task_description}
{feature_name} = kebab-case de {task_description}
```

### 2. Mode Resume (SEULEMENT si resume_task est défini)

```bash
ls .claude/output/apex/ | grep "^{resume_task}"
```

- Si trouvé → Lire 00-context.md, restaurer les variables, trouver dernière étape complète, continuer
- Si plusieurs matches → Lister et demander de préciser
- Si non trouvé → Lister les tâches disponibles

### 3. Branch mode (si branch_mode = true)

```bash
git branch --show-current
```

- Si sur main/master et auto_mode → créer `feat/{feature_name}`
- Si sur main/master et pas auto_mode → demander via AskUserQuestion
- Si déjà sur branche feature → continuer

### 4. Créer structure output (si save_mode = true)

```bash
bash .claude/skills/apex/scripts/setup-templates.sh \
  "{feature_name}" "{task_description}" \
  "{auto_mode}" "{save_mode}" "{economy_mode}" \
  "{branch_mode}" "{branch_name}"
```

Capture le `TASK_ID` retourné par le script.

### 5. Afficher résumé COMPACT et continuer

```
✓ APEX: {task_description}

| Variable        | Valeur          |
|-----------------|-----------------|
| {task_id}       | NN-feature-name |
| {auto_mode}     | true/false      |
| {save_mode}     | true/false      |
| {economy_mode}  | true/false      |
| {branch_mode}   | true/false      |

→ Analyse en cours...
```

Puis charger immédiatement `step-01-analyze.md`.

---

## INDICATEUR ECONOMY MODE

Si economy_mode = true, afficher en premier :
```
⚡ ECONOMY MODE — Outils directs, pas de subagents
```

---

## CRITÈRES DE SUCCÈS

✅ Tous les flags parsés correctement
✅ Output compact (un tableau, pas de logs verbeux)
✅ Structure output créée si save_mode
✅ Passage immédiat à step-01 après le résumé
