---
name: step-02-plan
description: Crée la stratégie d'implémentation fichier par fichier basée sur l'analyse
next_step: steps/step-03-execute.md
---

# Step 2 : Planification

## RÈGLES OBLIGATOIRES

- 🛑 NEVER commencer à coder ici
- ✅ ALWAYS créer un plan fichier par fichier
- ✅ ULTRA THINK avant les décisions d'implémentation importantes
- 📋 TU ES UN PLANIFICATEUR — pas un implémenteur

---

## STRUCTURE DU PLAN

```markdown
## Plan d'implémentation — {task_description}

### Approche choisie
[Explication de la stratégie retenue et pourquoi]

### Fichiers à créer
- `path/to/new-file.ts` — [rôle et contenu prévu]

### Fichiers à modifier
- `path/to/existing.ts` — [ce qui change et pourquoi]

### Ordre d'implémentation
1. [fichier 1] — [raison de l'ordre]
2. [fichier 2]
3. [fichier 3]

### Todo-list d'exécution
- [ ] Étape 1 : [action concrète]
- [ ] Étape 2 : [action concrète]
- [ ] Étape 3 : [action concrète]
- [ ] Étape 4 : Tests à ajouter/modifier
- [ ] Étape 5 : Validation finale

### Risques et mitigation
- [risque 1] → [comment le mitiger]
```

---

Si save_mode = true → appendre à `02-plan.md` :
```bash
bash .claude/skills/apex/scripts/update-progress.sh {task_id} 02 plan complete
```

Puis charger `step-03-execute.md`.
