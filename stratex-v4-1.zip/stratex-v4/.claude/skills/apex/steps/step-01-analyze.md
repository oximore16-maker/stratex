---
name: step-01-analyze
description: Analyse le codebase et comprend le contexte pour la tâche
next_step: steps/step-02-plan.md
---

# Step 1 : Analyse

## RÈGLES OBLIGATOIRES

- 🛑 NEVER commencer l'implémentation dans cette phase
- ✅ ALWAYS explorer avant de planifier
- 📋 TU ES UN EXPLORATEUR — pas un implémenteur
- ✅ Si economy_mode → utiliser outils directs UNIQUEMENT

---

## STANDARD MODE (economy_mode = false)

Lance 1 à 7 agents d'exploration en parallèle selon la complexité :

| Complexité | Agents | Cas |
|------------|--------|-----|
| Simple | 1-2 | Bug fix, petit tweak |
| Moyen | 2-4 | Feature dans stack connue |
| Complexe | 4-7 | Librairies inconnues, intégrations |

**Agents disponibles :**
- `explore-codebase` → Trouve les patterns existants, fichiers, utilitaires
- `explore-docs` → Recherche documentation librairie (si API inconnue)
- `websearch` → Meilleures pratiques, approches, gotchas

**Sois intelligent :** Analyse ce dont tu as besoin avant de lancer. Ne sur-lance pas pour les tâches simples.

---

## ⚡ ECONOMY MODE (economy_mode = true)

```
⚡ ECONOMY MODE — Exploration directe, pas de subagents
```

**Stratégie d'exploration économique :**

```
1. Glob pour trouver les fichiers concernés :
   - Glob: "**/*{keyword}*"
   - Glob: "src/**/*.ts" pour une zone spécifique

2. Grep pour trouver le code spécifique :
   - Grep: le pattern exact cherché
   - Grep: dans le dossier concerné

3. Read pour les 3-5 fichiers les plus pertinents

4. WebSearch UNIQUEMENT si :
   - Documentation de librairie inconnue nécessaire
   - Limiter à 1-2 recherches maximum
```

---

## FINDINGS À DOCUMENTER

À la fin de l'analyse, noter :

```markdown
## Analyse — {task_description}

### Contexte codebase
- Stack : [technologies identifiées]
- Patterns existants : [patterns pertinents trouvés]
- Fichiers concernés : [liste des fichiers à modifier]

### État actuel
- [ce qui existe déjà et comment ça fonctionne]

### Gaps identifiés
- [ce qui manque ou doit changer]

### Points d'attention
- [risques, dépendances, contraintes]

### Questions résolues
- Q: [question] → R: [réponse trouvée]
```

Si save_mode = true → appendre à `01-analyze.md` :
```bash
bash .claude/skills/apex/scripts/update-progress.sh {task_id} 01 analyze complete
```

---

## PASSAGE À L'ÉTAPE SUIVANTE

Après l'analyse, charger `step-02-plan.md` avec les findings en contexte.
