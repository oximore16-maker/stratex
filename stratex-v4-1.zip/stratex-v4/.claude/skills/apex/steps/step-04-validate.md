---
name: step-04-validate
description: Valide l'implémentation — typecheck, tests, auto-review ou adversarial review
---

# Step 4 : Validation

## RÈGLES OBLIGATOIRES

- ✅ ALWAYS lancer typecheck et lint en premier
- ✅ ALWAYS lancer les tests après typecheck
- 🛑 Si tests échouent → activer le skill ralph-loop avant de continuer
- ✅ Mode standard : déléguer à @stratex-reviewer pour l'adversarial review
- ✅ Mode economy : self-review avec checklist

---

## VALIDATION STANDARD (economy_mode = false)

### Phase 1 : Checks techniques
```bash
# TypeScript / lint
npx tsc --noEmit
npx eslint src/ --ext .ts,.tsx

# Tests
npm test
# OU
npx jest --testPathPattern=[feature-related]
```

### Phase 2 : Adversarial review
Déléguer à `@stratex-reviewer` avec comme context :
- Les fichiers modifiés
- Le scope de la feature
- Les critères d'acceptance

### Phase 3 : Résolution findings
Adresser tous les findings Critical et High avant de déclarer Done.

---

## ⚡ VALIDATION ECONOMY MODE

```
⚡ ECONOMY MODE — Self-review sans subagents
```

### Phase 1 : Checks techniques (identiques)
```bash
npx tsc --noEmit
npx eslint src/
npm test -- --testPathPattern=[feature]
```

### Phase 2 : Self-review checklist
```
- [ ] Sécurité : pas d'injection, pas de secrets exposés
- [ ] Logique : erreurs gérées, edge cases couverts
- [ ] Qualité : suit les patterns existants, lisible
- [ ] Tests : happy path + au moins 1 error case
- [ ] Performance : pas de requête N+1 évidente
```

---

## GESTION DES TESTS QUI ÉCHOUENT

Si les tests échouent, activer le skill ralph-loop :
```
Tests en échec détectés → Activation ralph-loop skill
→ Lire .claude/skills/ralph-loop.md
→ Diagnostiquer, corriger, relancer
→ Recommencer jusqu'à ce que les tests passent
```

---

## RAPPORT FINAL

```markdown
## Validation — {task_description}

### Résultat global
✅ DONE | ⚠️ PARTIEL | ❌ BLOQUÉ

### Checks techniques
- TypeScript : ✅ 0 erreurs
- Lint : ✅ 0 warnings
- Tests : ✅ [N] pass, 0 fail

### Review
- Mode : Standard (adversarial) | Economy (self-review)
- Findings résolus : [N Critical, N High]
- Findings reportés : [N Medium/Low — backlog]

### Critères d'acceptance
- [x] AC1 : ✅ Validé
- [x] AC2 : ✅ Validé

### Prochaines étapes suggérées
- [ ] PR vers main (utiliser `/apex -b` au prochain run)
- [ ] Notifier l'équipe
- [ ] Mettre à jour le sprint dashboard
```

Si save_mode = true → appendre à `04-validate.md` :
```bash
bash .claude/skills/apex/scripts/update-progress.sh {task_id} 04 validate complete
```

---

## RÉSUMÉ DE COMPLÉTION

Toujours terminer avec :
```
🎯 APEX COMPLETED — {task_description}

Phase 1 Analyze : ✅
Phase 2 Plan    : ✅
Phase 3 Execute : ✅
Phase 4 Validate: ✅

Fichiers modifiés : [N]
Tests : [N] pass
Commits : [N]
Durée estimée : [X] min

Output sauvegardé : .claude/output/apex/{task_id}/  [si save_mode]
```
