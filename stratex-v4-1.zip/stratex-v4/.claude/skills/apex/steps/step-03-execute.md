---
name: step-03-execute
description: Implémente la solution selon le plan établi, en cochant chaque étape
next_step: steps/step-04-validate.md
---

# Step 3 : Exécution

## RÈGLES OBLIGATOIRES

- ✅ ALWAYS suivre le plan de l'étape 2
- ✅ ALWAYS cocher chaque todo à mesure de la complétion
- ✅ ALWAYS commit après chaque bloc logique cohérent
- 🛑 NEVER dévier du plan sans noter le changement et la raison
- ✅ Si blocage → noter et continuer avec le reste, revenir ensuite

---

## PROTOCOLE D'EXÉCUTION

### 1. Reprendre la todo-list du plan

Afficher la todo-list et cocher chaque item à mesure :
```
- [x] Étape 1 : ✅ Complété
- [ ] Étape 2 : En cours...
- [ ] Étape 3 : À faire
```

### 2. Implémenter chaque étape

Pour chaque étape :
1. **Read** les fichiers à modifier (always read before write)
2. **Implémenter** le changement
3. **Vérifier** que le changement est correct
4. **Cocher** l'item de la todo-list

### 3. Commits atomiques

Après chaque bloc logique cohérent :
```bash
git add -A
git commit -m "feat: [description courte de ce qui vient d'être implémenté]"
```

### 4. Log de déviations

Si le plan doit être adapté :
```
⚠️ DÉVIATION : [description du changement par rapport au plan]
Raison : [pourquoi c'est nécessaire]
Impact : [ce que ça change]
```

---

## LOG D'EXÉCUTION

```markdown
## Exécution — {task_description}

### Actions effectuées
- ✅ [action 1] — [notes si pertinent]
- ✅ [action 2]
- ⚠️ [action 3] — DÉVIATION : [raison]

### Fichiers créés
- `path/to/new-file.ts`

### Fichiers modifiés
- `path/to/modified.ts` — [résumé des changements]

### Commits
- [hash court] : [message]

### Blocages rencontrés
- [blocage si applicable] → [résolution]
```

Si save_mode = true → appendre à `03-execute.md` :
```bash
bash .claude/skills/apex/scripts/update-progress.sh {task_id} 03 execute complete
```

Puis charger `step-04-validate.md`.
