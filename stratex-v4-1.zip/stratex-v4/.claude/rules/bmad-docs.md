---
paths:
  - "docs/stories/**/*"
  - "docs/prd.md"
  - "docs/architecture.md"
---

# BMAD Document Rules — STRATEX v2

These rules apply ONLY when working on BMAD planning documents.

## Story format (mandatory)
Every story must contain:
- **Title:** [verb] [object] (e.g. "Implement JWT authentication")
- **Epic:** parent epic reference
- **Estimate:** story points or hours
- **Acceptance Criteria:** numbered list, each testable and binary (pass/fail)
- **Dependencies:** list of blocking stories or sessions
- **Notes:** implementation hints for the Dev agent

## Acceptance Criteria rules
- Each AC must be independently testable
- Write ACs as: "Given [context], when [action], then [outcome]"
- Minimum 3 ACs per story, maximum 10
- ACs become the validation.md of the Apex session — write them precisely

## sprint-status.yaml rules
- Updated only by /sync-sprint — never manually
- Status values: Todo | In Progress | Done | Blocked
- Blocked stories must include a `blocking_reason` field

## PRD rules
- Never rewrite PRD during implementation — only append
- Architecture decisions belong in architecture.md, not PRD
- Each PRD section must map to at least one epic
