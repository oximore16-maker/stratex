---
paths:
  - "src/api/**/*.ts"
  - "src/app/api/**/*.ts"
---

# API Rules — STRATEX v2

These rules apply ONLY when working on API files.

## Validation
- Always validate all inputs with Zod before any processing
- Never trust raw request body — always parse and validate
- Return explicit HTTP status codes (400, 401, 403, 404, 422, 500)
- Never return stack traces or internal error details to the client

## Structure
- Keep route handlers thin — delegate logic to service classes in `src/lib/`
- Never query the database directly in route handlers — use repository pattern
- Always handle async errors with try/catch — never let unhandled rejections escape

## Security
- Always authenticate before authorizing
- Never log sensitive data (passwords, tokens, PII)
- Rate limit all public endpoints
- Sanitize all user inputs before storage

## Response format
Always return consistent response shapes:
```typescript
// Success
{ data: T, meta?: { page, total } }

// Error
{ error: { code: string, message: string } }
```
