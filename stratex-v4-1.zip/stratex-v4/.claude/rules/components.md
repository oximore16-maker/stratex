---
paths:
  - "src/components/**/*.tsx"
  - "src/app/**/*.tsx"
---

# Component Rules — STRATEX v2

These rules apply ONLY when working on UI component files.

## React patterns
- Prefer Server Components by default — only add "use client" when strictly necessary
- Never fetch data inside client components — use server components or React Query
- Keep components focused: one responsibility per component
- Extract reusable logic into custom hooks in `src/lib/hooks/`

## Styling
- Use Tailwind utility classes exclusively — no inline styles
- Follow the existing design system tokens — never hardcode colors or spacing
- Mobile-first: always write base styles for mobile, then md: lg: breakpoints

## Performance
- Lazy load heavy components with dynamic imports
- Memoize expensive computations with useMemo
- Never cause unnecessary re-renders — check dependencies carefully

## Accessibility
- All interactive elements must have aria labels
- Images always need meaningful alt text
- Maintain keyboard navigation support
