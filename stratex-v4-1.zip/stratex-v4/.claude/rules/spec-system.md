---
paths:
  - ".spec_system/**/*"
---

# Apex Spec System Rules — STRATEX v2

These rules apply ONLY when working inside .spec_system/ files.

## Session management
- Never modify state.json manually — always use Apex commands
- spec.md is read-only once /implement has started
- tasks.md checkboxes are the single source of truth for session progress
- Maximum 25 tasks per session — split if more are needed

## CONSIDERATIONS.md
- Add a new entry after EVERY session, no exceptions
- Format: `## [date] [session-id] — [one-line summary]`
- Include: what worked, what to avoid next time, any patterns discovered
- This file is read at the start of every new session — keep it actionable

## spec.md writing rules
- Objective: 2-3 sentences max
- Out of scope section is MANDATORY — prevents scope creep
- Target files list must be exhaustive — no surprise file creation during session
- Security considerations must be filled, never left blank

## Budget rules
- If a spec would require > 15 target files → split into 2 sessions
- If estimated duration > 4h → split into 2 sessions
- If tasks > 25 → split into 2 sessions
