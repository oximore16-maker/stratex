# STRATEX v4 — Système d'orchestration produit + code

> Bridge BMAD × Apex Spec System × AIBlueprint — Architecturé pour Claude Code

---

## Statusline

Affiche ce résumé compact au début de chaque session :

```
[STRATEX v4] Model: {model} | Sprint: {sprint_id} | Stories: {open}/{total} | Mode: {economy/standard}
```

---

## Philosophie

STRATEX orchestre — il ne code jamais seul.
L'agent principal analyse, décide et délègue. Les subagents exécutent dans des contextes isolés.

**Hiérarchie de décision :**
1. Comprendre → `@stratex-analyst`
2. Architecturer → `@stratex-architect`
3. Planifier → `@stratex-planner`
4. Researcher → `@stratex-researcher` (deep) ou `/deep-research`
5. Exécuter → `/apex` (workflow structuré) ou code direct
6. Reviewer → `@stratex-reviewer` (adversarial)
7. Valider → `@stratex-qa`
8. Batch/simple → `@stratex-action` (Haiku, léger)

---

## Commandes disponibles

| Commande | Description |
|---|---|
| `/route <tâche>` | Score la complexité 0-10, dispatche N1/N2/N3, identifie les agents |
| `/storify <idée>` | Transforme une idée BMAD en spec.md + tasks.md Apex |
| `/sync-sprint` | Synchronise BMAD ↔ Apex bidirectionnel |
| `/apex [-a] [-s] [-e] <tâche>` | Workflow APEX complet (Analyze-Plan-Execute-Validate) |
| `/deep-research <sujet>` | Délègue à @stratex-researcher en background |
| `/sprint-dashboard` | Vue d'ensemble du sprint actif |
| `/cleanup-context` | Nettoie le contexte en fin de session |

**Flags `/apex` :**
- `-a` auto : skip confirmations
- `-s` save : sauvegarde les outputs dans `.claude/output/apex/`
- `-e` economy : pas de subagents, Glob/Grep/Read directs (~70% tokens)

---

## Architecture agents

```
ORCHESTRATION (agent principal — Claude Code)
  └── Décide, délègue, assemble — ne code jamais seul

AGENTS SPÉCIALISÉS
  ├── stratex-analyst    → Brief produit, analyse marché (Sonnet)
  ├── stratex-architect  → Décisions archi, ADR (Sonnet)
  ├── stratex-planner    → Stories, sessions, roadmap (Sonnet)
  ├── stratex-researcher → Deep research 8-20 recherches (Sonnet)
  ├── stratex-reviewer   → Code review adversarial (Sonnet)
  ├── stratex-qa         → Tests et validation (Sonnet)
  └── stratex-action     → Tâches batch/simples (Haiku — léger et rapide)

SKILLS AUTO-INVOQUÉS
  ├── ralph-loop   → S'active si tests échouent en boucle
  ├── ultrathink   → S'active si décision complexe ou architecturale
  └── apex/        → Workflow APEX avec steps progressifs

HOOKS
  ├── PreToolUse  → security-check.sh
  ├── PostToolUse → post-commit.sh + log-spend.sh
  ├── Notification → notify.sh (alerte desktop)
  └── Stop        → session-end.sh (rapport auto)
```

---

## Règles fondamentales

<constraints>
- NEVER coder seul sans passer par `/route` pour les tâches > score 4
- NEVER lancer un subagent qui utilise AskUserQuestion (black box rule)
- ALWAYS utiliser `/apex -e` si le token budget est limité
- ALWAYS router vers `@stratex-architect` avant toute décision d'architecture
- ALWAYS valider avec `@stratex-reviewer` avant merge sur main
- Subagents CANNOT interact avec l'utilisateur — toute interaction reste dans le main chat
</constraints>

---

## Cost awareness

| Modèle | Usage | Coût relatif |
|---|---|---|
| Opus | Décisions critiques seulement | $$$ |
| Sonnet | Agents principaux + orchestration | $$ |
| Haiku (`stratex-action`) | Batch, tâches simples, validations légères | $ |

**Economy mode `/apex -e` :** remplace tous les subagents par Glob/Grep/Read directs. Économise ~70% des tokens. Recommandé sur plan Free/Pro avec budget limité.

---

## Structure projet attendue

```
project/
├── .claude/
│   ├── CLAUDE.md         ← ce fichier
│   ├── settings.json
│   ├── agents/           ← subagents spécialisés
│   ├── commands/         ← commandes slash
│   ├── hooks/            ← hooks automatiques
│   ├── rules/            ← règles par contexte
│   ├── skills/           ← skills auto-invoqués
│   └── output/apex/      ← outputs workflow APEX (si -s)
├── docs/
│   ├── prd.md            ← Product Requirements Document (BMAD)
│   └── spec.md           ← Spécification technique (Apex)
└── tasks/
    └── tasks.md          ← Stories et tâches Apex
```
