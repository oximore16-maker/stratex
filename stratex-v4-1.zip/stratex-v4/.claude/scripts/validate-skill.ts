#!/usr/bin/env npx tsx
/**
 * STRATEX v4 — Skill Validator
 * Valide la structure d'un skill STRATEX avant packaging
 * Usage: npx tsx validate-skill.ts <path-to-skill>
 */

import { readFileSync, existsSync } from "fs";
import { join } from "path";

interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

interface SkillFrontmatter {
  name?: string;
  description?: string;
  "argument-hint"?: string;
  "allowed-tools"?: string;
  model?: string;
  maxTurns?: number;
  "disable-model-invocation"?: boolean;
  "user-invocable"?: boolean;
}

function parseFrontmatter(content: string): {
  frontmatter: SkillFrontmatter;
  body: string;
} {
  const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---\n([\s\S]*)$/);
  if (!frontmatterMatch) {
    return { frontmatter: {}, body: content };
  }

  const frontmatterStr = frontmatterMatch[1];
  const body = frontmatterMatch[2];

  // Simple YAML parser pour les cas courants
  const frontmatter: SkillFrontmatter = {};
  for (const line of frontmatterStr.split("\n")) {
    const match = line.match(/^(\w[\w-]*)\s*:\s*(.+)$/);
    if (match) {
      const key = match[1] as keyof SkillFrontmatter;
      const value = match[2].trim().replace(/^['"]|['"]$/g, "");
      (frontmatter as Record<string, unknown>)[key] =
        value === "true" ? true : value === "false" ? false : value;
    }
  }

  return { frontmatter, body };
}

function validateSkill(skillPath: string): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Vérifier que le fichier existe
  if (!existsSync(skillPath)) {
    return {
      valid: false,
      errors: [`Fichier introuvable : ${skillPath}`],
      warnings: [],
    };
  }

  const content = readFileSync(skillPath, "utf-8");
  const { frontmatter, body } = parseFrontmatter(content);

  // === VALIDATION FRONTMATTER ===

  // Pour les agents (.claude/agents/) — name et description requis
  if (skillPath.includes("/agents/")) {
    if (!frontmatter.name) {
      errors.push("Frontmatter manquant : 'name' est requis pour les agents");
    }
    if (!frontmatter.description) {
      errors.push(
        "Frontmatter manquant : 'description' est requis pour les agents"
      );
    }
    if (frontmatter.description && frontmatter.description.length < 50) {
      warnings.push(
        "Description trop courte (<50 chars) — aide au routing automatique"
      );
    }
    if (frontmatter.model && !["sonnet", "haiku", "opus", "inherit"].includes(frontmatter.model)) {
      errors.push(
        `Model invalide : '${frontmatter.model}'. Valeurs acceptées : sonnet, haiku, opus, inherit`
      );
    }
  }

  // Pour les commandes (.claude/commands/) — description recommandée
  if (skillPath.includes("/commands/")) {
    if (!frontmatter.description) {
      warnings.push(
        "Frontmatter : 'description' recommandée pour les commandes"
      );
    }
  }

  // === VALIDATION BODY ===

  // Vérifier pas de headings markdown dans le body des agents
  if (skillPath.includes("/agents/")) {
    const markdownHeadings = body.match(/^#{1,3}\s+.+/gm);
    if (markdownHeadings && markdownHeadings.length > 0) {
      errors.push(
        `Body contient des headings Markdown (${markdownHeadings.length} trouvés) — utiliser des tags XML à la place`
      );
      errors.push(`  Premiers headings : ${markdownHeadings.slice(0, 3).join(", ")}`);
    }

    // Vérifier présence des tags XML requis
    if (!body.includes("<role>")) {
      errors.push("Tag XML manquant : <role> est requis dans les agents");
    }
    if (!body.includes("<constraints>")) {
      warnings.push("Tag XML recommandé : <constraints> absent");
    }
    if (!body.includes("<success_criteria>")) {
      warnings.push("Tag XML recommandé : <success_criteria> absent");
    }
  }

  // Vérifier AskUserQuestion dans les agents (interdit)
  if (skillPath.includes("/agents/") && body.includes("AskUserQuestion")) {
    errors.push(
      "AskUserQuestion interdit dans les agents (subagent black box rule)"
    );
  }

  // Vérifier longueur body minimale
  if (body.trim().length < 100) {
    warnings.push("Body très court (<100 chars) — le skill semble incomplet");
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

function validateSkillDirectory(dirPath: string): void {
  const glob = require("glob") as { sync: (pattern: string) => string[] };

  const agentFiles = glob.sync(join(dirPath, ".claude/agents/*.md"));
  const commandFiles = glob.sync(join(dirPath, ".claude/commands/*.md"));
  const skillFiles = glob.sync(join(dirPath, ".claude/skills/**/*.md"));

  const allFiles = [...agentFiles, ...commandFiles, ...skillFiles];

  if (allFiles.length === 0) {
    console.log("⚠️  Aucun fichier skill/agent/commande trouvé");
    return;
  }

  let totalErrors = 0;
  let totalWarnings = 0;

  console.log(`\n🔍 Validation STRATEX — ${allFiles.length} fichiers\n`);

  for (const file of allFiles) {
    const result = validateSkill(file);
    const relativePath = file.replace(dirPath + "/", "");

    if (result.valid && result.warnings.length === 0) {
      console.log(`  ✅ ${relativePath}`);
    } else if (result.valid) {
      console.log(`  ⚠️  ${relativePath}`);
      for (const w of result.warnings) {
        console.log(`       → ${w}`);
      }
    } else {
      console.log(`  ❌ ${relativePath}`);
      for (const e of result.errors) {
        console.log(`       ✗ ${e}`);
      }
      for (const w of result.warnings) {
        console.log(`       → ${w}`);
      }
    }

    totalErrors += result.errors.length;
    totalWarnings += result.warnings.length;
  }

  console.log(`\n${"─".repeat(50)}`);
  console.log(
    `Résultat : ${totalErrors === 0 ? "✅ Valide" : "❌ Invalide"} | ${totalErrors} erreurs, ${totalWarnings} warnings`
  );

  if (totalErrors > 0) {
    process.exit(1);
  }
}

// Main
const target = process.argv[2];

if (!target) {
  console.error("Usage: npx tsx validate-skill.ts <path>");
  process.exit(1);
}

if (existsSync(join(target, ".claude"))) {
  // Répertoire projet complet
  validateSkillDirectory(target);
} else {
  // Fichier unique
  const result = validateSkill(target);
  if (result.valid && result.warnings.length === 0) {
    console.log(`✅ ${target} — Valide`);
  } else {
    if (result.errors.length > 0) {
      console.log(`❌ ${target} — ${result.errors.length} erreur(s) :`);
      result.errors.forEach((e) => console.log(`  ✗ ${e}`));
    }
    if (result.warnings.length > 0) {
      result.warnings.forEach((w) => console.log(`  ⚠️  ${w}`));
    }
    if (!result.valid) process.exit(1);
  }
}
