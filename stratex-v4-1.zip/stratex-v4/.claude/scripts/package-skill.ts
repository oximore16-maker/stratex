#!/usr/bin/env npx tsx
/**
 * STRATEX v4 — Skill Packager
 * Package le framework STRATEX en archive distribuable
 * Usage: npx tsx package-skill.ts <source-dir> [output-name]
 */

import { execSync } from "child_process";
import { existsSync, readFileSync, mkdirSync } from "fs";
import { join, basename } from "path";

interface PackageOptions {
  sourceDir: string;
  outputName: string;
  outputDir: string;
}

function getVersion(sourceDir: string): string {
  const claudeMdPath = join(sourceDir, ".claude/CLAUDE.md");
  if (existsSync(claudeMdPath)) {
    const content = readFileSync(claudeMdPath, "utf-8");
    const versionMatch = content.match(/STRATEX\s+(v[\d.]+)/i);
    if (versionMatch) return versionMatch[1];
  }
  return "v4";
}

function validateBeforePackaging(sourceDir: string): boolean {
  console.log("🔍 Validation avant packaging...\n");
  try {
    execSync(`npx tsx "${join(sourceDir, ".claude/scripts/validate-skill.ts")}" "${sourceDir}"`, {
      stdio: "inherit",
    });
    return true;
  } catch {
    console.error("\n❌ Validation échouée — packaging annulé");
    return false;
  }
}

function packageSkill(options: PackageOptions): void {
  const { sourceDir, outputName, outputDir } = options;

  if (!existsSync(sourceDir)) {
    console.error(`❌ Répertoire source introuvable : ${sourceDir}`);
    process.exit(1);
  }

  // Valider avant de packager
  const isValid = validateBeforePackaging(sourceDir);
  if (!isValid) {
    process.exit(1);
  }

  // Créer le répertoire output si nécessaire
  mkdirSync(outputDir, { recursive: true });

  const outputPath = join(outputDir, `${outputName}.zip`);

  console.log(`\n📦 Packaging STRATEX...\n`);

  // Créer l'archive ZIP
  const excludePatterns = [
    "--exclude=*.zip",
    "--exclude=node_modules/*",
    "--exclude=.git/*",
    "--exclude=*.log",
    "--exclude=.DS_Store",
    "--exclude=dist/*",
    "--exclude=output/*",
  ].join(" ");

  const sourceDirName = basename(sourceDir);
  const parentDir = join(sourceDir, "..");

  execSync(
    `cd "${parentDir}" && zip -r "${outputPath}" "${sourceDirName}" ${excludePatterns}`,
    { stdio: "inherit" }
  );

  // Vérifier la taille
  const { statSync } = require("fs");
  const stats = statSync(outputPath);
  const sizeKB = Math.round(stats.size / 1024);

  console.log(`\n✅ Package créé : ${outputPath}`);
  console.log(`   Taille : ${sizeKB} KB`);

  // Lister le contenu
  console.log(`\n📋 Contenu :`);
  execSync(`unzip -l "${outputPath}" | grep -v "Archive:" | head -40`, {
    stdio: "inherit",
  });
}

// Main
const sourceDir = process.argv[2] || ".";
const outputName = process.argv[3] || `stratex-${getVersion(sourceDir)}`;
const outputDir = process.argv[4] || "./dist";

packageSkill({
  sourceDir: join(process.cwd(), sourceDir),
  outputName,
  outputDir: join(process.cwd(), outputDir),
});
