#!/bin/bash
# STRATEX v3 — Session End Hook
# Rapport automatique quand une session Claude se termine

STATE_FILE=".spec_system/state.json"
SPEND_LOG=".claude/spend.log"
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

if [ ! -f "$STATE_FILE" ]; then
  exit 0
fi

SESSION_ID=$(jq -r '.current_session // "unknown"' "$STATE_FILE" 2>/dev/null || echo "unknown")
TASKS_DONE=$(grep -c "^- \[x\]" ".spec_system/specs/$SESSION_ID/tasks.md" 2>/dev/null || echo "?")
TASKS_TOTAL=$(grep -c "^- \[" ".spec_system/specs/$SESSION_ID/tasks.md" 2>/dev/null || echo "?")

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🏁 STRATEX — Session terminée"
echo "   Session : $SESSION_ID"
echo "   Tâches : $TASKS_DONE / $TASKS_TOTAL complétées"
echo "   Timestamp : $TIMESTAMP"
echo ""
echo "   Rappels :"
echo "   → /sync-sprint pour synchroniser BMAD"
echo "   → Mettre à jour CONSIDERATIONS.md si pas fait"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Log dans spend.log
echo "[$TIMESTAMP] SESSION_END | session: $SESSION_ID | tasks: $TASKS_DONE/$TASKS_TOTAL" >> "$SPEND_LOG"

exit 0
