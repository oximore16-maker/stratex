#!/bin/bash
# STRATEX v2 — Post-commit hook

STATE_FILE=".spec_system/state.json"
SPRINT_STATUS="docs/stories/sprint-status.yaml"

if [ ! -f "$STATE_FILE" ] || [ ! -f "$SPRINT_STATUS" ]; then
  exit 0
fi

TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
COMMIT_MSG=$(git log -1 --pretty=%B | head -1)
COMMIT_HASH=$(git rev-parse --short HEAD)

jq --arg ts "$TIMESTAMP" \
   --arg msg "$COMMIT_MSG" \
   --arg hash "$COMMIT_HASH" \
   '.last_commit = {"hash": $hash, "message": $msg, "timestamp": $ts}' \
   "$STATE_FILE" > /tmp/state_tmp.json && mv /tmp/state_tmp.json "$STATE_FILE"

echo "🔄 STRATEX: State synced after commit $COMMIT_HASH"
echo "   Run /sync-sprint for a full sync"
