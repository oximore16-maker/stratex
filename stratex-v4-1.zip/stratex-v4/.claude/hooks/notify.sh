#!/bin/bash
# STRATEX v3 — Notification Hook
# Alerte quand une tâche longue se termine (subagent, build, etc.)

MESSAGE="$1"
TIMESTAMP=$(date +"%H:%M")

# macOS
if command -v osascript &> /dev/null; then
  osascript -e "display notification \"$MESSAGE\" with title \"STRATEX\" subtitle \"$TIMESTAMP\""
fi

# Linux (notify-send)
if command -v notify-send &> /dev/null; then
  notify-send "STRATEX" "$MESSAGE"
fi

# Terminal bell (universel)
echo -e "\a"
echo "🔔 STRATEX [$TIMESTAMP]: $MESSAGE"

exit 0
