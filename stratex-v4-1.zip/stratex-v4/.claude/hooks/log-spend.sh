#!/bin/bash
# STRATEX v2 — Token Spend Logger
# Tracks session cost after each significant command
# Feeds data into /route for cost-aware dispatching

SPEND_LOG=".claude/spend.log"
STATE_FILE=".spec_system/state.json"
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
COMMAND="$1"

mkdir -p .claude
touch "$SPEND_LOG"

# Get current session info from state.json if available
SESSION_ID="unknown"
if [ -f "$STATE_FILE" ]; then
  SESSION_ID=$(jq -r '.current_session // "unknown"' "$STATE_FILE" 2>/dev/null || echo "unknown")
fi

# Log the command execution for cost tracking
echo "[$TIMESTAMP] SESSION: $SESSION_ID | CMD: $COMMAND" >> "$SPEND_LOG"

# Check if ccusage is available for real cost tracking
if command -v ccusage &> /dev/null; then
  COST=$(ccusage session 2>/dev/null | tail -1)
  echo "[$TIMESTAMP] COST: $COST" >> "$SPEND_LOG"

  # Update state.json with current session cost
  if [ -f "$STATE_FILE" ] && [ ! -z "$COST" ]; then
    jq --arg cost "$COST" --arg ts "$TIMESTAMP" \
       '.session_cost = {"amount": $cost, "updated_at": $ts}' \
       "$STATE_FILE" > /tmp/state_tmp.json && mv /tmp/state_tmp.json "$STATE_FILE"
  fi
fi

exit 0
