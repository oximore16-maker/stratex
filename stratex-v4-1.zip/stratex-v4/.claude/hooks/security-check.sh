#!/bin/bash
# STRATEX v2 — Security Check Hook
# Intercepts shell commands BEFORE execution
# Blocks dangerous operations and logs all attempts

COMMAND="$1"
LOG_FILE=".claude/security.log"
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# Ensure log file exists
mkdir -p .claude
touch "$LOG_FILE"

# ─────────────────────────────────────────
# BLOCKLIST — Commands that are NEVER allowed
# ─────────────────────────────────────────
BLOCKED_PATTERNS=(
  "rm -rf /"
  "rm -rf ~"
  "rm -rf \*"
  "chmod 777"
  "sudo rm"
  "sudo chmod"
  "> /etc/"
  "dd if="
  "mkfs"
  ":(){:|:&};:"
  "curl.*|.*sh"
  "wget.*|.*sh"
  "eval \$(curl"
  "eval \$(wget"
  "base64 -d.*|.*sh"
  "chmod +x.*&&"
)

for pattern in "${BLOCKED_PATTERNS[@]}"; do
  if echo "$COMMAND" | grep -qi "$pattern"; then
    echo "🚨 STRATEX SECURITY: Command BLOCKED" >&2
    echo "   Command: $COMMAND" >&2
    echo "   Reason: Matches dangerous pattern: $pattern" >&2
    echo "   Action: Logged to .claude/security.log" >&2

    # Log the blocked attempt
    echo "[$TIMESTAMP] BLOCKED | Pattern: $pattern | Command: $COMMAND" >> "$LOG_FILE"

    exit 1  # Block execution
  fi
done

# ─────────────────────────────────────────
# WARNLIST — Commands that trigger a warning but are allowed
# ─────────────────────────────────────────
WARN_PATTERNS=(
  "rm -rf"
  "DROP TABLE"
  "DELETE FROM.*WHERE"
  "truncate"
  "git push --force"
  "git reset --hard"
)

for pattern in "${WARN_PATTERNS[@]}"; do
  if echo "$COMMAND" | grep -qi "$pattern"; then
    echo "⚠️  STRATEX SECURITY: High-risk command detected" >&2
    echo "   Command: $COMMAND" >&2
    echo "   Proceeding — logged to .claude/security.log" >&2

    # Log the warning
    echo "[$TIMESTAMP] WARNING | Pattern: $pattern | Command: $COMMAND" >> "$LOG_FILE"

    # Allow execution to continue
    break
  fi
done

# Log all commands for audit trail (silent)
echo "[$TIMESTAMP] ALLOWED | Command: $COMMAND" >> "$LOG_FILE"

exit 0
